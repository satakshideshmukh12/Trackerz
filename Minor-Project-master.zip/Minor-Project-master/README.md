# Minor-Project
Web Application for managing different works of employees in different companies.
